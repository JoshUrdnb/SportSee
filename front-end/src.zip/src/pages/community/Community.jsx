import './community.scss'

export default function Community() {
    return (
        <div className='community'>

        </div>
    )
}