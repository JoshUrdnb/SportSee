import './settings.scss'

export default function Settings() {
    return (
        <div className='settings'>

        </div>
    )
}